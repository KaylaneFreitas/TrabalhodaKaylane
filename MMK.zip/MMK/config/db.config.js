module.exports = {
    HOST: "localhost",
    USER: "postgres",
    PASSWORD: "postgres",
    DB: "vitoria" ,
    dialect: "postgres",
    };